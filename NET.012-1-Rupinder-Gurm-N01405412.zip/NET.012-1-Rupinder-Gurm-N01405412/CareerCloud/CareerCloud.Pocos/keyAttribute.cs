﻿using System;

namespace CareerCloud.Pocos
{
    internal class keyAttribute : Attribute
    {
    }
}